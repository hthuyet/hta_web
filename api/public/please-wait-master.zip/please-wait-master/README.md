PleaseWait.js
===========
A simple library to show your users a beautiful splash page while your application loads.

Documentation and Demo
---------------------
Documentation and demo can be found [here](http://pathgather.github.io/please-wait/).

About Pathgather
---------------------
Pathgather is an NYC-based startup building a platform that dramatically accelerates learning for enterprises by bringing employees, training content, and existing enterprise systems into one engaging platform.

Every Friday, we work on open-source software (our own or other projects). Want to join our always growing team? Peruse our [current opportunities](http://www.pathgather.com/jobs/) or reach out to us at <tech@pathgather.com>!